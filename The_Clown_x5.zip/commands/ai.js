const fetch = require('node-fetch');
module.exports = {
  name: 'ai',
  desc: 'Question à l’IA: !ai <question>',
  usage: '!ai <question>',
  admin: false,
  exec: async ({ sock, from, args, CONFIG }) => {
    const q = args.join(' ');
    if (!q) return await sock.sendMessage(from, { text: 'Usage: !ai <question>' });
    if (!CONFIG.OPENAI_API_KEY) return await sock.sendMessage(from, { text: 'AI non configurée. Ajoute OPENAI_API_KEY.' });
    try {
      const resp = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${CONFIG.OPENAI_API_KEY}` },
        body: JSON.stringify({ model: 'gpt-4o-mini', messages: [{ role: 'user', content: q }], max_tokens: 400 })
      });
      const data = await resp.json();
      const answer = data?.choices?.[0]?.message?.content || JSON.stringify(data);
      await sock.sendMessage(from, { text: 'AI: ' + answer });
    } catch (e) {
      await sock.sendMessage(from, { text: 'Erreur AI: ' + e.message });
    }
  }
};