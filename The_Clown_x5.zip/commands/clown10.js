module.exports = {
  name: 'clown10',
  desc: 'Template fun #10',
  usage: '!clown10',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown10 !' });
  }
};