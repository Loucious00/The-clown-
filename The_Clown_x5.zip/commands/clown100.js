module.exports = {
  name: 'clown100',
  desc: 'Template fun #100',
  usage: '!clown100',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown100 !' });
  }
};