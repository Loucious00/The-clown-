module.exports = {
  name: 'clown101',
  desc: 'Template fun #101',
  usage: '!clown101',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown101 !' });
  }
};