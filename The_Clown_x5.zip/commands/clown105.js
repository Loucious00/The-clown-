module.exports = {
  name: 'clown105',
  desc: 'Template fun #105',
  usage: '!clown105',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown105 !' });
  }
};