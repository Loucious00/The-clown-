module.exports = {
  name: 'clown106',
  desc: 'Template fun #106',
  usage: '!clown106',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown106 !' });
  }
};