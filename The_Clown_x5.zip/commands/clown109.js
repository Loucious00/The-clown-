module.exports = {
  name: 'clown109',
  desc: 'Template fun #109',
  usage: '!clown109',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown109 !' });
  }
};