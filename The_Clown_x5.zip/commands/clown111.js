module.exports = {
  name: 'clown111',
  desc: 'Template fun #111',
  usage: '!clown111',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown111 !' });
  }
};