module.exports = {
  name: 'clown112',
  desc: 'Template fun #112',
  usage: '!clown112',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown112 !' });
  }
};