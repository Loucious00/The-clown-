module.exports = {
  name: 'clown12',
  desc: 'Template fun #12',
  usage: '!clown12',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown12 !' });
  }
};