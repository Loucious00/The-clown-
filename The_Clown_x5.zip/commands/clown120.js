module.exports = {
  name: 'clown120',
  desc: 'Template fun #120',
  usage: '!clown120',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown120 !' });
  }
};