module.exports = {
  name: 'clown123',
  desc: 'Template fun #123',
  usage: '!clown123',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown123 !' });
  }
};