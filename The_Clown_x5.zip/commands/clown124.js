module.exports = {
  name: 'clown124',
  desc: 'Template fun #124',
  usage: '!clown124',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown124 !' });
  }
};