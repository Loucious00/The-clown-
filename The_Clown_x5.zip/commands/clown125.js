module.exports = {
  name: 'clown125',
  desc: 'Template fun #125',
  usage: '!clown125',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown125 !' });
  }
};