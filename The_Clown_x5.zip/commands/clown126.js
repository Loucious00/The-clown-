module.exports = {
  name: 'clown126',
  desc: 'Template fun #126',
  usage: '!clown126',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown126 !' });
  }
};