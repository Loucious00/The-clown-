module.exports = {
  name: 'clown127',
  desc: 'Template fun #127',
  usage: '!clown127',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown127 !' });
  }
};