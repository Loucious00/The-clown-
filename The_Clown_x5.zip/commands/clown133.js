module.exports = {
  name: 'clown133',
  desc: 'Template fun #133',
  usage: '!clown133',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown133 !' });
  }
};