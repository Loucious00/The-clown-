module.exports = {
  name: 'clown134',
  desc: 'Template fun #134',
  usage: '!clown134',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown134 !' });
  }
};