module.exports = {
  name: 'clown138',
  desc: 'Template fun #138',
  usage: '!clown138',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown138 !' });
  }
};