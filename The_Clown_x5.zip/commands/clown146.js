module.exports = {
  name: 'clown146',
  desc: 'Template fun #146',
  usage: '!clown146',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown146 !' });
  }
};