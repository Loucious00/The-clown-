module.exports = {
  name: 'clown147',
  desc: 'Template fun #147',
  usage: '!clown147',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown147 !' });
  }
};