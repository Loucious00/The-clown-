module.exports = {
  name: 'clown151',
  desc: 'Template fun #151',
  usage: '!clown151',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown151 !' });
  }
};