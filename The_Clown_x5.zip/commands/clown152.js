module.exports = {
  name: 'clown152',
  desc: 'Template fun #152',
  usage: '!clown152',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown152 !' });
  }
};