module.exports = {
  name: 'clown153',
  desc: 'Template fun #153',
  usage: '!clown153',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown153 !' });
  }
};