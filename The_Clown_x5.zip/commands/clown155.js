module.exports = {
  name: 'clown155',
  desc: 'Template fun #155',
  usage: '!clown155',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown155 !' });
  }
};