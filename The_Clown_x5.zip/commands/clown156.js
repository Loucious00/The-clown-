module.exports = {
  name: 'clown156',
  desc: 'Template fun #156',
  usage: '!clown156',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown156 !' });
  }
};