module.exports = {
  name: 'clown157',
  desc: 'Template fun #157',
  usage: '!clown157',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown157 !' });
  }
};