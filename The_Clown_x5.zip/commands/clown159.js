module.exports = {
  name: 'clown159',
  desc: 'Template fun #159',
  usage: '!clown159',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown159 !' });
  }
};