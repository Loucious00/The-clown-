module.exports = {
  name: 'clown160',
  desc: 'Template fun #160',
  usage: '!clown160',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown160 !' });
  }
};