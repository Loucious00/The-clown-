module.exports = {
  name: 'clown161',
  desc: 'Template fun #161',
  usage: '!clown161',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown161 !' });
  }
};