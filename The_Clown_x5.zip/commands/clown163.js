module.exports = {
  name: 'clown163',
  desc: 'Template fun #163',
  usage: '!clown163',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown163 !' });
  }
};