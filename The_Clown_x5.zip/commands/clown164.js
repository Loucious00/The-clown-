module.exports = {
  name: 'clown164',
  desc: 'Template fun #164',
  usage: '!clown164',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown164 !' });
  }
};