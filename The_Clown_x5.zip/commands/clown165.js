module.exports = {
  name: 'clown165',
  desc: 'Template fun #165',
  usage: '!clown165',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown165 !' });
  }
};