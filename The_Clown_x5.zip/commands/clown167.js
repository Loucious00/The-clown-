module.exports = {
  name: 'clown167',
  desc: 'Template fun #167',
  usage: '!clown167',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown167 !' });
  }
};