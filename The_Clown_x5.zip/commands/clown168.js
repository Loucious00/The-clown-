module.exports = {
  name: 'clown168',
  desc: 'Template fun #168',
  usage: '!clown168',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown168 !' });
  }
};