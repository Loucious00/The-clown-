module.exports = {
  name: 'clown169',
  desc: 'Template fun #169',
  usage: '!clown169',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown169 !' });
  }
};