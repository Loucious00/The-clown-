module.exports = {
  name: 'clown170',
  desc: 'Template fun #170',
  usage: '!clown170',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown170 !' });
  }
};