module.exports = {
  name: 'clown173',
  desc: 'Template fun #173',
  usage: '!clown173',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown173 !' });
  }
};