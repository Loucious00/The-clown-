module.exports = {
  name: 'clown174',
  desc: 'Template fun #174',
  usage: '!clown174',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown174 !' });
  }
};