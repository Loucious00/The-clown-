module.exports = {
  name: 'clown176',
  desc: 'Template fun #176',
  usage: '!clown176',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown176 !' });
  }
};