module.exports = {
  name: 'clown177',
  desc: 'Template fun #177',
  usage: '!clown177',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown177 !' });
  }
};