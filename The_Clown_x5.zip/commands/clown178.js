module.exports = {
  name: 'clown178',
  desc: 'Template fun #178',
  usage: '!clown178',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown178 !' });
  }
};