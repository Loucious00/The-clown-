module.exports = {
  name: 'clown179',
  desc: 'Template fun #179',
  usage: '!clown179',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown179 !' });
  }
};