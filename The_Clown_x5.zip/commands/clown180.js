module.exports = {
  name: 'clown180',
  desc: 'Template fun #180',
  usage: '!clown180',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown180 !' });
  }
};