module.exports = {
  name: 'clown182',
  desc: 'Template fun #182',
  usage: '!clown182',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown182 !' });
  }
};