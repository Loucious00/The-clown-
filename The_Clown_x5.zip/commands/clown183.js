module.exports = {
  name: 'clown183',
  desc: 'Template fun #183',
  usage: '!clown183',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown183 !' });
  }
};