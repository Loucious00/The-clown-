module.exports = {
  name: 'clown185',
  desc: 'Template fun #185',
  usage: '!clown185',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown185 !' });
  }
};