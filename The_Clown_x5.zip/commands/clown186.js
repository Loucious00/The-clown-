module.exports = {
  name: 'clown186',
  desc: 'Template fun #186',
  usage: '!clown186',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown186 !' });
  }
};