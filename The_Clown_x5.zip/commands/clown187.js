module.exports = {
  name: 'clown187',
  desc: 'Template fun #187',
  usage: '!clown187',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown187 !' });
  }
};