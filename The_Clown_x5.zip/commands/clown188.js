module.exports = {
  name: 'clown188',
  desc: 'Template fun #188',
  usage: '!clown188',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown188 !' });
  }
};