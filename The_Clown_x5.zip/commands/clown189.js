module.exports = {
  name: 'clown189',
  desc: 'Template fun #189',
  usage: '!clown189',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown189 !' });
  }
};