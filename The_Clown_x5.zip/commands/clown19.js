module.exports = {
  name: 'clown19',
  desc: 'Template fun #19',
  usage: '!clown19',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown19 !' });
  }
};