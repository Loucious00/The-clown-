module.exports = {
  name: 'clown190',
  desc: 'Template fun #190',
  usage: '!clown190',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown190 !' });
  }
};