module.exports = {
  name: 'clown194',
  desc: 'Template fun #194',
  usage: '!clown194',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown194 !' });
  }
};