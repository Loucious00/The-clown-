module.exports = {
  name: 'clown195',
  desc: 'Template fun #195',
  usage: '!clown195',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown195 !' });
  }
};