module.exports = {
  name: 'clown197',
  desc: 'Template fun #197',
  usage: '!clown197',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown197 !' });
  }
};