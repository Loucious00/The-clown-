module.exports = {
  name: 'clown198',
  desc: 'Template fun #198',
  usage: '!clown198',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown198 !' });
  }
};