module.exports = {
  name: 'clown2',
  desc: 'Template fun #2',
  usage: '!clown2',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown2 !' });
  }
};