module.exports = {
  name: 'clown20',
  desc: 'Template fun #20',
  usage: '!clown20',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown20 !' });
  }
};