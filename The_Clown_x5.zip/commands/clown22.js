module.exports = {
  name: 'clown22',
  desc: 'Template fun #22',
  usage: '!clown22',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown22 !' });
  }
};