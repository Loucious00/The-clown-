module.exports = {
  name: 'clown24',
  desc: 'Template fun #24',
  usage: '!clown24',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown24 !' });
  }
};