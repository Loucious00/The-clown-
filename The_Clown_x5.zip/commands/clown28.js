module.exports = {
  name: 'clown28',
  desc: 'Template fun #28',
  usage: '!clown28',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown28 !' });
  }
};