module.exports = {
  name: 'clown3',
  desc: 'Template fun #3',
  usage: '!clown3',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown3 !' });
  }
};