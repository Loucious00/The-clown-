module.exports = {
  name: 'clown31',
  desc: 'Template fun #31',
  usage: '!clown31',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown31 !' });
  }
};