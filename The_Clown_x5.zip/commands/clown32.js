module.exports = {
  name: 'clown32',
  desc: 'Template fun #32',
  usage: '!clown32',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown32 !' });
  }
};