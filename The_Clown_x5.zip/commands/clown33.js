module.exports = {
  name: 'clown33',
  desc: 'Template fun #33',
  usage: '!clown33',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown33 !' });
  }
};