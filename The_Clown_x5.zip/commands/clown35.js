module.exports = {
  name: 'clown35',
  desc: 'Template fun #35',
  usage: '!clown35',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown35 !' });
  }
};