module.exports = {
  name: 'clown36',
  desc: 'Template fun #36',
  usage: '!clown36',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown36 !' });
  }
};