module.exports = {
  name: 'clown4',
  desc: 'Template fun #4',
  usage: '!clown4',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown4 !' });
  }
};