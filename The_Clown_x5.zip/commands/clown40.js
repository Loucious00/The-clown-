module.exports = {
  name: 'clown40',
  desc: 'Template fun #40',
  usage: '!clown40',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown40 !' });
  }
};