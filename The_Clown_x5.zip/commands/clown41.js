module.exports = {
  name: 'clown41',
  desc: 'Template fun #41',
  usage: '!clown41',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown41 !' });
  }
};