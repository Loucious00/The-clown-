module.exports = {
  name: 'clown43',
  desc: 'Template fun #43',
  usage: '!clown43',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown43 !' });
  }
};