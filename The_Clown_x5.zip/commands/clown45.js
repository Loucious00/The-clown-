module.exports = {
  name: 'clown45',
  desc: 'Template fun #45',
  usage: '!clown45',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown45 !' });
  }
};