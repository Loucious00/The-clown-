module.exports = {
  name: 'clown46',
  desc: 'Template fun #46',
  usage: '!clown46',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown46 !' });
  }
};