module.exports = {
  name: 'clown47',
  desc: 'Template fun #47',
  usage: '!clown47',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown47 !' });
  }
};