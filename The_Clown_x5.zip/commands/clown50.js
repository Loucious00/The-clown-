module.exports = {
  name: 'clown50',
  desc: 'Template fun #50',
  usage: '!clown50',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown50 !' });
  }
};