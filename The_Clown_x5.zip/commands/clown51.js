module.exports = {
  name: 'clown51',
  desc: 'Template fun #51',
  usage: '!clown51',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown51 !' });
  }
};