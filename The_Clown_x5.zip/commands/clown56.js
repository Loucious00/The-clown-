module.exports = {
  name: 'clown56',
  desc: 'Template fun #56',
  usage: '!clown56',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown56 !' });
  }
};