module.exports = {
  name: 'clown57',
  desc: 'Template fun #57',
  usage: '!clown57',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown57 !' });
  }
};