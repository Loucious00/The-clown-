module.exports = {
  name: 'clown58',
  desc: 'Template fun #58',
  usage: '!clown58',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown58 !' });
  }
};