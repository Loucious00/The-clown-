module.exports = {
  name: 'clown60',
  desc: 'Template fun #60',
  usage: '!clown60',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown60 !' });
  }
};