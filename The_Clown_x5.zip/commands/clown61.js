module.exports = {
  name: 'clown61',
  desc: 'Template fun #61',
  usage: '!clown61',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown61 !' });
  }
};