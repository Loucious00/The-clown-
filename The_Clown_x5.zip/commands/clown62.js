module.exports = {
  name: 'clown62',
  desc: 'Template fun #62',
  usage: '!clown62',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown62 !' });
  }
};