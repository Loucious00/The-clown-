module.exports = {
  name: 'clown63',
  desc: 'Template fun #63',
  usage: '!clown63',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown63 !' });
  }
};