module.exports = {
  name: 'clown64',
  desc: 'Template fun #64',
  usage: '!clown64',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown64 !' });
  }
};