module.exports = {
  name: 'clown66',
  desc: 'Template fun #66',
  usage: '!clown66',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown66 !' });
  }
};