module.exports = {
  name: 'clown67',
  desc: 'Template fun #67',
  usage: '!clown67',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown67 !' });
  }
};