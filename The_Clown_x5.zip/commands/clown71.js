module.exports = {
  name: 'clown71',
  desc: 'Template fun #71',
  usage: '!clown71',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown71 !' });
  }
};