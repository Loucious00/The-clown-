module.exports = {
  name: 'clown72',
  desc: 'Template fun #72',
  usage: '!clown72',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown72 !' });
  }
};