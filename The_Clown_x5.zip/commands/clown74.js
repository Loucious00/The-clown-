module.exports = {
  name: 'clown74',
  desc: 'Template fun #74',
  usage: '!clown74',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown74 !' });
  }
};