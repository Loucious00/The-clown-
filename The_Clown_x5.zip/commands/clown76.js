module.exports = {
  name: 'clown76',
  desc: 'Template fun #76',
  usage: '!clown76',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown76 !' });
  }
};