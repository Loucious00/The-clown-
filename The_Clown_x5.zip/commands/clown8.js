module.exports = {
  name: 'clown8',
  desc: 'Template fun #8',
  usage: '!clown8',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown8 !' });
  }
};