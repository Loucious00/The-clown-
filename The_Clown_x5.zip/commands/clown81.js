module.exports = {
  name: 'clown81',
  desc: 'Template fun #81',
  usage: '!clown81',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown81 !' });
  }
};