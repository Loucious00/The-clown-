module.exports = {
  name: 'clown82',
  desc: 'Template fun #82',
  usage: '!clown82',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown82 !' });
  }
};