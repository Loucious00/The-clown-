module.exports = {
  name: 'clown84',
  desc: 'Template fun #84',
  usage: '!clown84',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown84 !' });
  }
};