module.exports = {
  name: 'clown86',
  desc: 'Template fun #86',
  usage: '!clown86',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown86 !' });
  }
};