module.exports = {
  name: 'clown90',
  desc: 'Template fun #90',
  usage: '!clown90',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown90 !' });
  }
};