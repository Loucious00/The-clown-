module.exports = {
  name: 'clown92',
  desc: 'Template fun #92',
  usage: '!clown92',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown92 !' });
  }
};