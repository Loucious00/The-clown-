module.exports = {
  name: 'clown94',
  desc: 'Template fun #94',
  usage: '!clown94',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown94 !' });
  }
};