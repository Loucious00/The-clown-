module.exports = {
  name: 'clown95',
  desc: 'Template fun #95',
  usage: '!clown95',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown95 !' });
  }
};