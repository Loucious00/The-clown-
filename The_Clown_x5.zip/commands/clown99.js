module.exports = {
  name: 'clown99',
  desc: 'Template fun #99',
  usage: '!clown99',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: 'Le clown dit: clown99 !' });
  }
};