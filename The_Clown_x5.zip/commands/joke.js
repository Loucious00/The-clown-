module.exports = {
  name: 'joke',
  desc: 'Envoie une blague courte',
  usage: '!joke',
  admin: false,
  exec: async ({ sock, from }) => {
    const jokes = [
      "Pourquoi les plongeurs plongent-ils toujours en arrière ? Parce que sinon ils tombent dans le bateau.",
      "Quel est le comble pour un électricien ? De ne pas être au courant.",
      "Pourquoi les squelettes ne se battent-ils jamais ? Ils n'ont pas le cœur à ça."
    ];
    const j = jokes[Math.floor(Math.random() * jokes.length)];
    await sock.sendMessage(from, { text: '🤡 Blague : ' + j });
  }
};