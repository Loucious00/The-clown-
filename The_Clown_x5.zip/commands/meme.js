module.exports = {
  name: 'meme',
  desc: 'Envoie un meme texte rigolo',
  usage: '!meme',
  admin: false,
  exec: async ({ sock, from }) => {
    const memes = [
      "Quand tu réalise que c'est lundi... 😩",
      "Moi après 3 heures de sieste : Je suis prêt pour la nuit.",
      "Prof: 'C'est facile' — Moi: '...'"
    ];
    const m = memes[Math.floor(Math.random() * memes.length)];
    await sock.sendMessage(from, { text: '🃏 Meme : ' + m });
  }
};