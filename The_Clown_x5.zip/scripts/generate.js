const fs = require('fs'), path = require('path');
const n = parseInt(process.argv[2] || '2000');
if (!fs.existsSync('commands')) fs.mkdirSync('commands');
for (let i=1;i<=n;i++) {
  const name = 'clown' + i;
  const content = `module.exports = {
  name: '${name}',
  desc: 'Commande template #${i}',
  usage: '!${name}',
  admin: false,
  exec: async ({ sock, from }) => {
    await sock.sendMessage(from, { text: '${name} exécutée. (template)' });
  }
};`;
  fs.writeFileSync(path.join('commands', name + '.js'), content);
}
console.log('Generated', n, 'commands in ./commands');